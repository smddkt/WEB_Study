import { useState } from 'react'
import './App.css'
import TodoItems from "./components/TodoItems"
import DoneItems from "./components/DoneItems"

function App() {

  const [todos, setTodos] = useState([
    { id: 1, content: "Send E-mail", isDone: false },
    { id: 2, content: "Make Work-Books", isDone: false },
    { id: 3, content: "Sleeping", isDone: true },
    { id: 4, content: "Watching You-Tube", isDone: true },
  ]);

  const [newInput, setNewInput] = useState("")
  const [doneTodo, setDoneTodo] = useState([]);


  function addTodoHandler(e) {
    if (e.key ==="Enter"){
    e.preventDefault()

    setTodos(currentTodos => [
        ...currentTodos, 
        {id: crypto.randomUUID(), content: newInput, isDone: false},
            ]
    )

    setNewInput("")
  }}

  function moveTodoHandler(id) {
    setTodos(currentTodos => currentTodos.filter(todo => todo.id !== id));
    const movedTodo = todos.find(todo => todo.id === id);
    setDoneTodo(currentDoneTodos => [
      ...currentDoneTodos, 
      { id: movedTodo.id, content: movedTodo.content, isDone: true },
    ]);
  }
  

  return (
    <form className="new-input" onKeyDown = {addTodoHandler}>
    <h1>UMC Study Plan</h1>
    <input
        value = {newInput}
        onChange={e => setNewInput(e.target.value)}
        type = "text" 
        placeholder='UMC 스터디 계획을 작성해보세요!'
        />
    <TodoItems todos={todos} moveTodoHandler={moveTodoHandler}/>
    <DoneItems doneTodo = {doneTodo}/>
    </form>
    )
}
export default App




