import React from "react"

function DoneItems(props){

    return (
        <div>
      <ul className = "list2">
        {props.doneTodo.map((item) => (
            <li key = {item.id}>
                {item.content}
                <button className="deleteBtn">삭제</button>
            </li>
        ))}
      </ul>
    </div>
    )
    
}

export default DoneItems