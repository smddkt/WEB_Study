import React from "react"

function TodoItems(props){
    const moveTodoHandler = (id)=> {
        setTodos((currentTodos) => currentTodos.filter((todo) => todo.id !== id));
        const movedTodo = todos.find(todo => todo.id === id);
        setDoneTodo(currentDoneTodos => [
          ...currentDoneTodos, 
          { id: movedTodo.id, content: movedTodo.content, isDone: true },
        ]);
      }

    
    return (
        <div>
        <ul className = "list1">
            {props.todos.map(todo => (
                <li key={todo.id}>
                    {todo.content}
                    <button className="doneBtn" onClick={() => moveTodoHandler(todo.id)}>완료</button>
                </li>
            ))}
        </ul>
        </div>
        )
    
}
export default TodoItems